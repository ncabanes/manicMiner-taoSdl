# manicMiner-taoSdl

In this folder you can find the appearance of the 20 original levels of
Manic Miner (Amstrad CPC version), both with the original colors and
with a grid over it to discover the tiles of each level:

Level 1:

![](manicMiner-Level01-grid.png)

![](manicMiner-Level01.png)

Level 2:

![](manicMiner-Level02-grid.png)

![](manicMiner-Level02.png)

Level 3:

![](manicMiner-Level03-grid.png)

![](manicMiner-Level03.png)

Level 4:

![](manicMiner-Level04-grid.png)

![](manicMiner-Level04.png)

Level 5:

![](manicMiner-Level05-grid.png)

![](manicMiner-Level05.png)

Level 6:

![](manicMiner-Level06-grid.png)

![](manicMiner-Level06.png)

Level 7:

![](manicMiner-Level07-grid.png)

![](manicMiner-Level07.png)

Level 8:

![](manicMiner-Level08-grid.png)

![](manicMiner-Level08.png)

Level 9:

![](manicMiner-Level09-grid.png)

![](manicMiner-Level09.png)

Level 10:

![](manicMiner-Level10-grid.png)

![](manicMiner-Level10.png)

Level 11:

![](manicMiner-Level11-grid.png)

![](manicMiner-Level11.png)

Level 12:

![](manicMiner-Level12-grid.png)

![](manicMiner-Level12.png)

Level 13:

![](manicMiner-Level13-grid.png)

![](manicMiner-Level13.png)

Level 14:

![](manicMiner-Level14-grid.png)

![](manicMiner-Level14.png)

Level 15:

![](manicMiner-Level15-grid.png)

![](manicMiner-Level15.png)

Level 16:

![](manicMiner-Level16-grid.png)

![](manicMiner-Level16.png)

Level 17:

![](manicMiner-Level17-grid.png)

![](manicMiner-Level17.png)

Level 18:

![](manicMiner-Level18-grid.png)

![](manicMiner-Level18.png)

Level 19:

![](manicMiner-Level19-grid.png)

![](manicMiner-Level19.png)

Level 20:

![](manicMiner-Level20-grid.png)

![](manicMiner-Level20.png)


