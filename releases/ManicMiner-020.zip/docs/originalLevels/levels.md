# manicMiner-taoSdl

In this folder you can find the appearance of the 20 original levels of
Manic Miner (Amstrad CPC version), both with the original colors and
with a grid over it to discover the tiles of each level:

![](manicMiner-Level01-grid.png)

![](manicMiner-Level01.png)

![](manicMiner-Level02-grid.png)

![](manicMiner-Level02.png)

![](manicMiner-Level03-grid.png)

![](manicMiner-Level03.png)

![](manicMiner-Level04-grid.png)

![](manicMiner-Level04.png)

![](manicMiner-Level05-grid.png)

![](manicMiner-Level05.png)

![](manicMiner-Level06-grid.png)

![](manicMiner-Level06.png)

![](manicMiner-Level07-grid.png)

![](manicMiner-Level07.png)

![](manicMiner-Level08-grid.png)

![](manicMiner-Level08.png)

![](manicMiner-Level09-grid.png)

![](manicMiner-Level09.png)

![](manicMiner-Level10-grid.png)

![](manicMiner-Level10.png)

![](manicMiner-Level11-grid.png)

![](manicMiner-Level11.png)

![](manicMiner-Level12-grid.png)

![](manicMiner-Level12.png)

![](manicMiner-Level13-grid.png)

![](manicMiner-Level13.png)

![](manicMiner-Level14-grid.png)

![](manicMiner-Level14.png)

![](manicMiner-Level15-grid.png)

![](manicMiner-Level15.png)

![](manicMiner-Level16-grid.png)

![](manicMiner-Level16.png)

![](manicMiner-Level17-grid.png)

![](manicMiner-Level17.png)

![](manicMiner-Level18-grid.png)

![](manicMiner-Level18.png)

![](manicMiner-Level19-grid.png)

![](manicMiner-Level19.png)

![](manicMiner-Level20-grid.png)

![](manicMiner-Level20.png)


