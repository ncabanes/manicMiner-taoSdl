# manicMiner-taoSdl

In this folder you can find several sprites extracted from the original game (Amstrad CPC version)

