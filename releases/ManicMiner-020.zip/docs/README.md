# manicMiner-taoSdl

In this folder you can find the a little documentation for the game,
such as the [originalLevels] and the [originalSprites].

Soon you will also have the classes diagram.

